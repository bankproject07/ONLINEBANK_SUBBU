package com.cg.obs.bean;

public class Customer {

	private long customer_ID;
	private String customer_Name;
	private String email;
	private long mobileNo;
	private String address;
	private String pancard;
	public long getCustomer_ID() {
		return customer_ID;
	}
	public void setCustomer_ID(Long customer_ID) {
		this.customer_ID = customer_ID;
	}
	public String getCustomer_Name() {
		return customer_Name;
	}
	public void setCustomer_Name(String customer_Name) {
		this.customer_Name = customer_Name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPancard() {
		return pancard;
	}
	public void setPancard(String pancard) {
		this.pancard = pancard;
	}
	
	
	public Long getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(Long mobileNo) {
		this.mobileNo = mobileNo;
	}
	
	
	public Customer(Long customer_ID, String customer_Name, String email, Long mobileNo, String address,
			String pancard) {
		super();
		this.customer_ID = customer_ID;
		this.customer_Name = customer_Name;
		this.email = email;
		this.mobileNo = mobileNo;
		this.address = address;
		this.pancard = pancard;
	}
	
	public Customer() {
		super();
	}
	
	
	
	@Override
	public String toString() {
		return "Customer [customer_ID=" + customer_ID + ", customer_Name=" + customer_Name + ", email=" + email
				+ ", mobileNo=" + mobileNo + ", address=" + address + ", pancard=" + pancard + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((address == null) ? 0 : address.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Customer other = (Customer) obj;
		if (address == null) {
			if (other.address != null)
				return false;
		} else if (!address.equals(other.address))
			return false;
		return true;
	}
	
	
	
	
	
	}
