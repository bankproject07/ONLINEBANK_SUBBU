package com.cg.obs.service;


import java.sql.Date;
import java.util.List;

import com.cg.obs.bean.AccountMaster;
import com.cg.obs.bean.Admin;
import com.cg.obs.bean.Customer;
import com.cg.obs.bean.FundTransfer;
import com.cg.obs.bean.Payee;
import com.cg.obs.bean.RequestTable;
import com.cg.obs.bean.ServiceTracker;
import com.cg.obs.bean.Transactions;
import com.cg.obs.bean.Users;
import com.cg.obs.dao.AdminDaoImpl;
import com.cg.obs.dao.IAdminDao;
import com.cg.obs.dao.IUserDAO;
import com.cg.obs.dao.UserDAOImpl;
import com.cg.obs.exception.UserException;

public class UserServiceImpl implements IUserService {

	IUserDAO userDao;
	IAdminDao adminDao;
	public UserServiceImpl() {
		userDao=new UserDAOImpl();
		adminDao=new AdminDaoImpl();
	}
	
	
	
	@Override
	public Users getUser(int id) throws UserException {
		
		return userDao.getUser(id);
	}

	



	@Override
	public List<Transactions> getMiniTransactions(Long accountno) throws UserException {
		
		System.out.println("In service");
		return userDao.getMiniTransactions(accountno);
	}

	
	@Override
	public List<Transactions> getDetailedTransactions(Long accountno,Date fromDate,Date toDate) throws UserException
	{
		return userDao.getDetailedTransactions(accountno, fromDate, toDate);
		
}

	@Override
	public int getCustomerId(Long accountno) throws UserException {
		// TODO Auto-generated method stub
		return userDao.getCustomerId(accountno);
	}



	@Override
	public Customer getCustomer(int customerid) throws UserException {
		// TODO Auto-generated method stub
		return userDao.getCustomer(customerid);
	
	}
	
	@Override
	public void updateCustomerDetails(Customer customer) throws UserException {
	
		userDao.updateCustomerDetails(customer);
	}


	@Override
	public int requestService(ServiceTracker services) throws UserException {
		
		return userDao.requestService(services);
	}



	@Override
	public int fundTransfer(FundTransfer transferInfo) throws UserException {
		// TODO Auto-generated method stub
		return userDao.fundTransfer(transferInfo);
	}



	@Override
	public void changePassword(Users user) throws UserException {

		userDao.changePassword(user);
		
	}



	@Override
	public void updateLockStatus(int userid) throws UserException {
		
		userDao.updateLockStatus(userid);
		
	}



	@Override
	public List<Payee> getPayee(long accountid) throws UserException {
		// TODO Auto-generated method stub
		return userDao.getPayee(accountid);
	}



	@Override
	public void insertPayee(Payee payee) throws UserException {
		// TODO Auto-generated method stub
		userDao.insertPayee(payee);
	}



	@Override
	public AccountMaster getAccount(long accountno) {
		// TODO Auto-generated method stub
		return userDao.getAccount(accountno);
	}



	@Override
	public void insertTransaction(Transactions transaction)
			throws UserException {

		userDao.insertTransaction(transaction);
		
	}



	@Override
	public void updateBalance(double updatedBalance,Long accountNo) throws UserException {
		
		userDao.updateBalance(updatedBalance,accountNo);
	}



	@Override
	public boolean isPayeeAccountExists(long payeeAccountNo)
			throws UserException {
		// TODO Auto-generated method stub
		return userDao.isPayeeAccountExists(payeeAccountNo);
	}



	@Override
	public List<RequestTable> getAllRequest() throws UserException {
		// TODO Auto-generated method stub
		return adminDao.getAllRequest();
	}



	@Override
	public Admin getAdmin() throws UserException {
		// TODO Auto-generated method stub
		return adminDao.getAdmin();
	}



	@Override
	public boolean isCustomerExist(int id) throws UserException {
		// TODO Auto-generated method stub
		return adminDao.isCustomerExist(id);
	}



	@Override
	public int addUsers(Customer customer) throws UserException {
		// TODO Auto-generated method stub
		return adminDao.addUsers(customer);
	}



	@Override
	public int addUsers(AccountMaster accountMaster) throws UserException {
		// TODO Auto-generated method stub
		return adminDao.addUsers(accountMaster);
	}



	@Override
	public RequestTable getAccountId(int custId) throws UserException {
		// TODO Auto-generated method stub
		return userDao.getAccountId(custId);
	}



	@Override
	public int registerUser(Users user, Customer customer) throws UserException {
		// TODO Auto-generated method stub
		return userDao.registerUser(user, customer);
	}



	@Override
	public Customer getCustomerbyId(int id) throws UserException {
		// TODO Auto-generated method stub
		return adminDao.getCustomerbyId(id);
	}



	@Override
	public int addRequest(RequestTable resTab) throws UserException {
		// TODO Auto-generated method stub
		return userDao.addRequest(resTab);
	}



	@Override
	public List<Transactions> viewMonthlyReport(Date StartDate, Date EndDate)
			throws UserException {
		// TODO Auto-generated method stub
		return adminDao.viewMonthlyReport(StartDate, EndDate);
	}



	@Override
	public List<Transactions> viewYearlyReport(Date StartDate, Date EndDate)
			throws UserException {
		// TODO Auto-generated method stub
		return adminDao.viewYearlyReport(StartDate, EndDate);
	}



	@Override
	public List<Transactions> viewDailyReport(Date StartDate)
			throws UserException {
		// TODO Auto-generated method stub
		return adminDao.viewDailyReport(StartDate);
	}

}


