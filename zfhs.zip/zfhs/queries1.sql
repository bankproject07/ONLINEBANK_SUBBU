
DROP table User_Table;
create table User_Table
(
user_id VARCHAR2(20) primary key,
Account_ID NUMBER,
login_password VARCHAR2(15),
secret_question VARCHAR2(50),
secret_answer VARCHAR2(50),
Transaction_password VARCHAR2(15),
lock_status VARCHAR2(10),foreign key(Account_ID) references Account_Master(Account_ID) 
);

insert into USER_TABLE VALUES(12345,1789542,'abcd','sd','bd','789','L');
select * from USER_TABLE;

select * from TRANSACTION;

delete REQUESTTABLE;
select * from REQUESTTABLE;

select * from REQUESTTABLE;

drop table REQUESTTABLE;

select * from CUSTOMER;
delete customer where customer_id=1500243;

delete REQUESTTABLE where customer_id=1500243;

insert into customer values(custid_seq.nextVal,'John','john@yahoo.com','Mumbai','A896964');
create table RequestTable
(
customer_ID number(10) primary key,
AccountType varchar2(15),
AccountId number(10)
);

insert into REQUESTTABLE values (1500242,'Saving',accid_seq.nextVal);
select accountId from REQUESTTABLE;